package com.src;

public class Address {
	private String hno;
	private String streetname;
	private String cityname;
	private String state;
	private String country;
	private long pincode;
	
}
