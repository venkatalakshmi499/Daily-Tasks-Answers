package com.src;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class EmailConstraintValidator implements ConstraintValidator<Email,String> {

	public boolean isValid(String value, ConstraintValidatorContext context) {
		// TODO Auto-generated method stub
		
		boolean result=value.contains("@");
		boolean result1=value.contains(".");
		if(result && result1)
		{
			return result;
			
		}
		
		return false;
	}

}
