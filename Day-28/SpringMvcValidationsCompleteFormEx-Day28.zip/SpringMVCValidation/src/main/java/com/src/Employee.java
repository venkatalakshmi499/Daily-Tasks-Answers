package com.src;
//import javax.validation.constraints.Pattern;
//import javax.validation.constraints.Pattern;
//import javax.validation.constraints.Size;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

public class Employee {
	//@Pattern(regexp="[^a-z]",message="enter case sensitive")
	//@Pattern(regexp="^[a-zA-Z0-9] {3}", message="invalid")
	private String name;
	//@Size(min=4,message="required")
	//@Password
	//@Email
	private String pass;
	@Email
	private String email;
	@Size(min=8,message="required")
	private String lname;
	@Min(value=10, message="must be equal to10")  
	//@Max(value=10, message="must be equal to 10")  
	private long mob;
	private String city;
    private String state;
    private String address;
    @Min(value=18, message="must be equal or greater than 18")  
    @Max(value=45, message="must be equal or less than 45")  
    private int age;
    
	
	
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public long getMob() {
		return mob;
	}
	public void setMob(long mob) {
		this.mob = mob;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
}
